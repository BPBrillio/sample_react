export const staticLocation = ["Delhi", "Chennai", "Bengaluru", "Bengaluru"];
export const uniqueLocation = [...new Set(staticLocation.map((item) => item))];
